const express = require('express');

const app = express();

app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());


const employees = [
{
    employeeID: "ESC100",
    name: "Annie Boadu",
    position: "secretary",
    age: "24"
},
{
    employeeID:"ESC200",
    name: "Alexis Boadu",
    position:"HR manager",
    age:"22"
},
{
employeeID:"ESC300",
name:"Sakyibea Boadu",
position:"Manager",
age:"23"
},
{
    employeeID:"ESC400",
    name:"Dominica Amanfo",
    position:"IT Manager",
    age:"23"
    },


]
app.get('/', (req, res) =>{
    res.render("home", {
employees 
    });
});


const port = 5100;
app.listen(port, () => {
    console.log(`server has started at port ${ port } ..`)
});